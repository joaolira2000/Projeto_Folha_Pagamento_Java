
import java.util.ArrayList;
import java.util.Scanner;

public class FolhaPagamento {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Colaborador> colaboradores = new ArrayList<>();
        int opcao;

        do {
            System.out.println("
=== SISTEMA DE FOLHA DE PAGAMENTO ===");
            System.out.println("1 - Cadastrar colaborador");
            System.out.println("2 - Listar colaboradores");
            System.out.println("0 - Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();

            switch (opcao) {
                case 1: cadastrarColaborador(scanner, colaboradores); break;
                case 2: listarColaboradores(colaboradores); break;
                case 0: System.out.println("Encerrando o sistema..."); break;
                default: System.out.println("Opção inválida!");
            }
        } while (opcao != 0);

        scanner.close();
    }

    public static void cadastrarColaborador(Scanner scanner, ArrayList<Colaborador> colaboradores) {
        System.out.print("Número de registro: ");
        int registro = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Nome completo: ");
        String nome = scanner.nextLine();

        System.out.println("Tipo de colaborador:");
        System.out.println("1 - Funcionário Padrão");
        System.out.println("2 - Funcionário Comissionado");
        System.out.println("3 - Funcionário de Produção");
        int tipo = scanner.nextInt();

        double salarioFinal = Colaborador.SALARIO_BASE;

        if (tipo == 2) {
            System.out.print("Valor total de vendas: ");
            double vendas = scanner.nextDouble();
            System.out.print("Percentual de comissão: ");
            double percentual = scanner.nextDouble();
            salarioFinal += (vendas * percentual) / 100;
        } else if (tipo == 3) {
            System.out.print("Valor por peça: ");
            double valorPorPeca = scanner.nextDouble();
            System.out.print("Quantidade produzida: ");
            int quantidade = scanner.nextInt();
            salarioFinal += valorPorPeca * quantidade;
        }

        colaboradores.add(new Colaborador(registro, nome, tipo, salarioFinal));
        System.out.println("Colaborador cadastrado com sucesso!");
    }

    public static void listarColaboradores(ArrayList<Colaborador> colaboradores) {
        for (Colaborador c : colaboradores) {
            System.out.println("Registro: " + c.getRegistro());
            System.out.println("Nome: " + c.getNome());
            System.out.println("Tipo: " + c.getTipoDescricao());
            System.out.printf("Salário Final: R$ %.2f
", c.getSalarioFinal());
            System.out.println("------------------------");
        }
    }
}
