
public class Colaborador {

    public static final double SALARIO_BASE = 2000.00;

    private int registro;
    private String nome;
    private int tipo;
    private double salarioFinal;

    public Colaborador(int registro, String nome, int tipo, double salarioFinal) {
        this.registro = registro;
        this.nome = nome;
        this.tipo = tipo;
        this.salarioFinal = salarioFinal;
    }

    public int getRegistro() {
        return registro;
    }

    public String getNome() {
        return nome;
    }

    public double getSalarioFinal() {
        return salarioFinal;
    }

    public String getTipoDescricao() {
        switch (tipo) {
            case 1: return "Funcionário Padrão";
            case 2: return "Funcionário Comissionado";
            case 3: return "Funcionário de Produção";
            default: return "Desconhecido";
        }
    }
}
