
Projeto Prático – Sistema de Folha de Pagamento em Java

Aluno: João Carlos Santos Lira
Curso: Análise e Desenvolvimento de Sistemas

Descrição:
Sistema em Java para cadastro de colaboradores e cálculo de folha de pagamento.

Como executar:
Executar a classe FolhaPagamento.java em uma IDE Java.
